import React, { useRef } from 'react';
import {
  Printer,
  Download,
  X,
  FileText,
  Footprints,
  BookOpen,
  Award,
  Calendar,
  Compass,
  FileSpreadsheet,
} from 'lucide-react';
import * as XLSX from '../utils/excelXml';
import { ResearchProject } from '../types';
import { LABS_DATA } from '../data/labsData';

interface PrintPreviewModalProps {
  project: ResearchProject;
  isOpen: boolean;
  onClose: () => void;
}

export const PrintPreviewModal: React.FC<PrintPreviewModalProps> = ({
  project,
  isOpen,
  onClose,
}) => {
  const printRef = useRef<HTMLDivElement>(null);

  if (!isOpen) return null;

  const lab = LABS_DATA.find((l) => l.id === project.labId) || LABS_DATA[0];

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadMarkdown = () => {
    const md = `
# [4P 읽걷쓰 전공연계 사회문제탐구 보고서]
## ${project.title}

- **전공 연구실**: ${lab.name} (${lab.englishName})
- **연구자**: ${project.author || '학생연구원'} (${project.affiliation || '학교명 미입력'})
- **작성일자**: ${project.updatedAt || project.createdAt}
- **핵심 질문**: ${project.mainQuestion}

---

### [4P 탐구 프레임워크]

#### P1. 현상 (Phenomenon)
${project.fourP.phenomenon || '(미작성)'}

#### P2. 문제 (Problem)
${project.fourP.problem || '(미작성)'}

#### P3. 과업 (Project / Task - 전공 연구방법론)
${project.fourP.project || '(미작성)'}

#### P4. 실천 (Practice - 사회적 적용)
${project.fourP.practice || '(미작성)'}

---

### [현장 걷기(Walk) 사색 기록]
${
  project.walkingLogs?.length > 0
    ? project.walkingLogs
        .map(
          (w) =>
            `- [${w.date}] ${w.courseName} (${w.activityType ? `${w.activityType} / ` : ''}${w.steps.toLocaleString()}보 / ${w.durationMinutes}분 / 몰입도 ${w.focusScore}점)\n  > 사색 메모: "${w.thoughtNote}"${
              w.findings ? `\n  > 현장 실측/인터뷰: "${w.findings}"` : ''
            }`
        )
        .join('\n\n')
    : '기록 없음'
}

---

### [탐독 문헌(Read) 목록]
${
  project.readingLogs?.length > 0
    ? project.readingLogs
        .map((r) => `- 《${r.title}》 (${r.author}, ${r.category})\n  > "${r.readingNotes}"`)
        .join('\n\n')
    : '기록 없음'
}

---

${
  project.evaluationResult
    ? `### [AI 학술 멘토링 진단 결과]
- 종합 점수: ${project.evaluationResult.totalScore}점 / 100점
- 멘토 총평: ${project.evaluationResult.overallReview}
- 추천 심화 질문: ${project.evaluationResult.questionUpgrades[2]?.question || ''}
`
    : ''
}
`;

    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `4P_연구보고서_${project.title.slice(0, 20)}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadTxt = () => {
    const txt = `
[4P 읽걷쓰 전공연계 사회문제탐구 계획서]
제목: ${project.title}
전공연구실: ${lab.name}
연구자: ${project.author} (${project.affiliation})
핵심질문: ${project.mainQuestion}

[P1 현상]
${project.fourP.phenomenon}

[P2 문제]
${project.fourP.problem}

[P3 과업]
${project.fourP.project}

[P4 실천]
${project.fourP.practice}
`;
    const blob = new Blob([txt], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `4P_연구보고서_${project.title.slice(0, 20)}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadExcel = () => {
    const wb = XLSX.utils.book_new();

    // Sheet 1: 4P 연구 프레임워크 및 종합 진단
    const overviewData = [
      ['4P 읽걷쓰 전공연계 사회문제탐구 연구보고서'],
      [''],
      ['구분', '내용'],
      ['연구 제목', project.title],
      ['전공 연구실', `${lab.name} (${lab.englishName})`],
      ['연구자(학생)', project.author || '학생연구원'],
      ['소속 기관/학교', project.affiliation || '학교명 미입력'],
      ['작성/수정일', project.updatedAt || project.createdAt || new Date().toISOString().slice(0, 10)],
      ['핵심 연구 질문', project.mainQuestion],
      [''],
      ['[4P 탐구 프레임워크]', ''],
      ['P1. 현상 (Phenomenon)', project.fourP.phenomenon || '(미작성)'],
      ['P2. 문제 (Problem)', project.fourP.problem || '(미작성)'],
      ['P3. 과업 (Project/Task - 전공 연구방법론)', project.fourP.project || '(미작성)'],
      ['P4. 실천 (Practice - 사회적 적용)', project.fourP.practice || '(미작성)'],
      [''],
      ['[AI 학술 멘토링 진단 결과]', ''],
      ['진단 종합점수', project.evaluationResult ? `${project.evaluationResult.totalScore}점 / 100점` : '평가 대기'],
      ['멘토 총평', project.evaluationResult ? project.evaluationResult.overallReview : '-'],
      ['심화 발전 질문', project.evaluationResult?.questionUpgrades?.[2]?.question || '-'],
    ];
    const wsOverview = XLSX.utils.aoa_to_sheet(overviewData);
    wsOverview['!cols'] = [{ wch: 28 }, { wch: 80 }];
    XLSX.utils.book_append_sheet(wb, wsOverview, '4P_연구프레임워크');

    // Sheet 2: 현장 걷기(Walk) 사색 및 실측 기록
    const walkingHeaders = [
      ['현장 걷기(Walk) 및 사색 활동 기록'],
      [''],
      ['순번', '탐구 일자', '인천 탐구 코스명', '활동 유형', '걸음수(보)', '소요시간(분)', '몰입도(1~5점)', '현장 사색 메모', '현장 실측 및 인터뷰 내용'],
    ];
    const walkingRows = (project.walkingLogs || []).map((w, idx) => [
      idx + 1,
      w.date,
      w.courseName,
      w.activityType || '관찰/사색',
      w.steps,
      w.durationMinutes,
      w.focusScore,
      w.thoughtNote,
      w.findings || '',
    ]);
    const wsWalking = XLSX.utils.aoa_to_sheet([...walkingHeaders, ...walkingRows]);
    wsWalking['!cols'] = [
      { wch: 6 },
      { wch: 14 },
      { wch: 30 },
      { wch: 14 },
      { wch: 12 },
      { wch: 12 },
      { wch: 12 },
      { wch: 45 },
      { wch: 45 },
    ];
    XLSX.utils.book_append_sheet(wb, wsWalking, '현장걷기_사색기록');

    // Sheet 3: 탐독 문헌(Read) 목록
    const readingHeaders = [
      ['학술 문헌(Read) 탐독 및 연구 노트 목록'],
      [''],
      ['순번', '도서 및 논문 제목', '저자', '분류/주제 영역', '핵심 발췌 및 사색 메모'],
    ];
    const readingRows = (project.readingLogs || []).map((r, idx) => [
      idx + 1,
      r.title,
      r.author,
      r.category,
      r.readingNotes,
    ]);
    const wsReading = XLSX.utils.aoa_to_sheet([...readingHeaders, ...readingRows]);
    wsReading['!cols'] = [
      { wch: 6 },
      { wch: 32 },
      { wch: 18 },
      { wch: 16 },
      { wch: 60 },
    ];
    XLSX.utils.book_append_sheet(wb, wsReading, '탐독문헌_노트');

    // Sheet 4: 전공 연구실 추천 인천 탐구 스팟
    const spotHeaders = [
      [`${lab.name} 전공연계 인천 핵심 현장탐구 스팟`],
      [''],
      ['순번', '장소명', '부제/성격', '위치/주소', '거리 및 소요시간', '추천 이유 및 탐구 연계점', '핵심 경유지'],
    ];
    const spotRows = (lab.walkingSpots || []).map((s, idx) => [
      idx + 1,
      s.name,
      s.subName,
      s.location,
      s.courseDistance || '-',
      s.reason || s.inquiryConnection || '',
      Array.isArray(s.keySpots) ? s.keySpots.join(', ') : '',
    ]);
    const wsSpots = XLSX.utils.aoa_to_sheet([...spotHeaders, ...spotRows]);
    wsSpots['!cols'] = [
      { wch: 6 },
      { wch: 28 },
      { wch: 35 },
      { wch: 30 },
      { wch: 18 },
      { wch: 50 },
      { wch: 40 },
    ];
    XLSX.utils.book_append_sheet(wb, wsSpots, '인천_추천탐구스팟');

    const sanitizedTitle = (project.title || '4P_연구보고서')
      .replace(/[\\/:*?"<>|]/g, '_')
      .slice(0, 20);
    XLSX.writeFile(wb, `4P_연구자료_${sanitizedTitle}.xlsx`);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
        {/* Modal Toolbar */}
        <div className="p-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 bg-slate-50 rounded-t-2xl">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-indigo-600" />
            <span className="text-sm font-bold text-slate-900">4P 연구 보고서 인쇄 미리보기</span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              id="btn-download-excel"
              onClick={handleDownloadExcel}
              className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs"
              title="연구계획서, 걷기 기록, 문헌 노트, 추천 스팟이 포함된 엑셀 호환(.xls) 파일로 저장"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
              <span>엑셀 시트(.xls) 저장</span>
            </button>

            <button
              onClick={handleDownloadMarkdown}
              className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all shadow-xs"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Markdown 다운로드</span>
            </button>

            <button
              onClick={handleDownloadTxt}
              className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all shadow-xs"
            >
              <Download className="w-3.5 h-3.5" />
              <span>TXT 다운로드</span>
            </button>

            <button
              id="btn-trigger-print"
              onClick={handlePrint}
              className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-xs transition-all"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>브라우저 인쇄 / PDF 저장</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Paper Document Container */}
        <div className="p-6 sm:p-10 overflow-y-auto grow bg-slate-100/50 flex justify-center">
          <div
            ref={printRef}
            id="printable-report"
            className="bg-white w-full max-w-3xl p-8 sm:p-12 rounded-xl shadow-xs border border-slate-200 text-slate-900 font-sans space-y-8 print:p-0 print:border-none print:shadow-none"
          >
            {/* Academic Header */}
            <div className="border-b-2 border-slate-900 pb-6 text-center space-y-2">
              <div className="flex items-center justify-center gap-2 text-xs font-semibold text-indigo-700 tracking-wider">
                <span>인천 지역 기반 읽·걷·쓰 전공연계 사회문제탐구</span>
                <span>•</span>
                <span>4P Inquiry Report</span>
              </div>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 leading-snug tracking-tight">
                {project.title || '4P 전공연계 사회문제탐구 보고서'}
              </h1>
              <div className="pt-2 flex flex-wrap items-center justify-center gap-4 text-xs text-slate-600 font-medium">
                <span>
                  <strong>전공 연구실:</strong> {lab.name}
                </span>
                <span>•</span>
                <span>
                  <strong>연구자:</strong> {project.author || '학생연구원'} ({project.affiliation || '소속 미기재'})
                </span>
                <span>•</span>
                <span>
                  <strong>최종 갱신일:</strong> {project.updatedAt || project.createdAt}
                </span>
              </div>
            </div>

            {/* Core Research Question Callout */}
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-300">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                핵심 탐구 질문 (Research Question)
              </span>
              <p className="text-sm font-bold text-indigo-950 leading-relaxed">
                &ldquo;{project.mainQuestion || '핵심 질문이 입력되지 않았습니다.'}&rdquo;
              </p>
            </div>

            {/* 4P Summary Matrix Table */}
            <div>
              <h2 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-1.5">
                <Compass className="w-4 h-4 text-indigo-600" />
                1. 4P 탐구 프레임워크 요약 매트릭스
              </h2>
              <div className="border border-slate-300 rounded-lg overflow-hidden text-xs">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-100 border-b border-slate-300 font-bold text-slate-800">
                      <th className="p-3 w-1/4 border-r border-slate-300">P1. 현상 (Phenomenon)</th>
                      <th className="p-3 w-1/4 border-r border-slate-300">P2. 문제 (Problem)</th>
                      <th className="p-3 w-1/4 border-r border-slate-300">P3. 과업 (Project)</th>
                      <th className="p-3 w-1/4">P4. 실천 (Practice)</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="divide-x divide-slate-300 align-top text-slate-700 leading-relaxed">
                      <td className="p-3 line-clamp-6 text-[11px]">{project.fourP.phenomenon || '-'}</td>
                      <td className="p-3 line-clamp-6 text-[11px]">{project.fourP.problem || '-'}</td>
                      <td className="p-3 line-clamp-6 text-[11px]">{project.fourP.project || '-'}</td>
                      <td className="p-3 line-clamp-6 text-[11px]">{project.fourP.practice || '-'}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* 4P Detailed Sections */}
            <div className="space-y-6">
              <h2 className="text-sm font-bold text-slate-900 border-b pb-2">
                2. 단계별 세부 탐구 및 학술 분석
              </h2>

              <div className="space-y-4 text-xs leading-relaxed">
                <div>
                  <h3 className="font-bold text-slate-900 text-xs mb-1 text-indigo-700">
                    [P1] 현상 포착 (Phenomenon)
                  </h3>
                  <p className="text-slate-800 whitespace-pre-line pl-3 border-l-2 border-indigo-300">
                    {project.fourP.phenomenon || '내용 없음'}
                  </p>
                </div>

                <div>
                  <h3 className="font-bold text-slate-900 text-xs mb-1 text-blue-700">
                    [P2] 문제 정의 및 원인 분석 (Problem)
                  </h3>
                  <p className="text-slate-800 whitespace-pre-line pl-3 border-l-2 border-blue-300">
                    {project.fourP.problem || '내용 없음'}
                  </p>
                </div>

                <div>
                  <h3 className="font-bold text-slate-900 text-xs mb-1 text-purple-700">
                    [P3] 전공 연계 연구 과업 (Project / Task)
                  </h3>
                  <p className="text-slate-800 whitespace-pre-line pl-3 border-l-2 border-purple-300">
                    {project.fourP.project || '내용 없음'}
                  </p>
                </div>

                <div>
                  <h3 className="font-bold text-slate-900 text-xs mb-1 text-emerald-700">
                    [P4] 사회적 실천 및 지속가능한 변화 (Practice)
                  </h3>
                  <p className="text-slate-800 whitespace-pre-line pl-3 border-l-2 border-emerald-300">
                    {project.fourP.practice || '내용 없음'}
                  </p>
                </div>
              </div>
            </div>

            {/* Walking Records */}
            <div>
              <h2 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-1.5 border-b pb-2">
                <Footprints className="w-4 h-4 text-emerald-600" />
                3. 현장 사색(걷기·Walk) 일지 및 관찰 데이터
              </h2>
              {project.walkingLogs?.length > 0 ? (
                <div className="space-y-2 text-xs">
                  {project.walkingLogs.map((w, idx) => (
                    <div key={idx} className="p-3 rounded-lg bg-slate-50 border border-slate-200">
                      <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1">
                        <div className="flex items-center gap-1.5 font-bold text-slate-800">
                          {w.activityType && (
                            <span className="px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800 text-[10px] font-medium">
                              {w.activityType}
                            </span>
                          )}
                          <span>{w.date} · {w.courseName}</span>
                        </div>
                        <span>
                          {w.steps.toLocaleString()}보 ({w.durationMinutes}분) | 몰입도: {w.focusScore}/5점
                        </span>
                      </div>
                      <p className="italic text-slate-700 leading-relaxed">&ldquo;{w.thoughtNote}&rdquo;</p>
                      {w.findings && (
                        <p className="text-[11px] text-indigo-900 bg-indigo-50/50 p-2 rounded mt-1.5 border border-indigo-100/60">
                          <strong className="text-indigo-700">현장 실측 / 육성 인용:</strong> {w.findings}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-slate-400">기록된 걷기 사색 일지가 없습니다.</p>
              )}
            </div>

            {/* Reading References */}
            <div>
              <h2 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-1.5 border-b pb-2">
                <BookOpen className="w-4 h-4 text-amber-600" />
                4. 탐독 문헌(읽기·Read) 및 참고 자료
              </h2>
              {project.readingLogs?.length > 0 ? (
                <div className="space-y-2 text-xs">
                  {project.readingLogs.map((r, idx) => (
                    <div key={idx} className="p-3 rounded-lg bg-slate-50 border border-slate-200">
                      <div className="font-bold text-slate-900 mb-0.5">
                        《{r.title}》 ({r.author}, {r.category})
                      </div>
                      <p className="text-[11px] text-slate-600">{r.readingNotes}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-slate-400">등록된 독서 탐구 기록이 없습니다.</p>
              )}
            </div>

            {/* AI Mentoring Result Stamp */}
            {project.evaluationResult && (
              <div className="p-4 rounded-xl border border-indigo-200 bg-indigo-50/40 text-xs space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-indigo-900 flex items-center gap-1">
                    <Award className="w-4 h-4 text-indigo-600" />
                    AI 학술 멘토 진단 종합 총평
                  </span>
                  <span className="font-black text-indigo-700">
                    종합 평점: {project.evaluationResult.totalScore}점 / 100점
                  </span>
                </div>
                <p className="text-slate-700 leading-relaxed">{project.evaluationResult.overallReview}</p>
                <div className="pt-2 border-t border-indigo-200/60 flex items-center gap-2 text-[11px] text-slate-600">
                  <strong>추천 심화 질문:</strong>
                  <span>{project.evaluationResult.questionUpgrades[2]?.question}</span>
                </div>
              </div>
            )}

            {/* Footer Sign-off */}
            <div className="pt-8 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-400">
              <span>인천 지역 기반 읽·걷·쓰 전공연계 사회문제탐구 플랫폼</span>
              <span>{project.isDemo ? '학습용 가상 예시 · 실제 조사 결과가 아님' : '학생 작성 자료 · 학교 확인란 별도'}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
