import express from 'express';
import type { Request, Response } from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';
import { INCHEON_20_GOV_DATASETS } from './src/data/incheonGovDatasets.ts';

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';

app.disable('x-powered-by');
app.use(express.json({ limit: '100kb' }));
app.use((_req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  next();
});

const aiRequestLog = new Map<string, { count: number; resetAt: number }>();
app.use('/api/gemini', (req, res, next) => {
  const key = req.ip || 'unknown';
  const now = Date.now();
  const current = aiRequestLog.get(key);
  if (!current || current.resetAt <= now) {
    aiRequestLog.set(key, { count: 1, resetAt: now + 10 * 60 * 1000 });
    return next();
  }
  if (current.count >= 20) {
    return res.status(429).json({ success: false, error: 'AI 요청 한도를 초과했습니다. 10분 후 다시 시도하세요.' });
  }
  current.count += 1;
  next();
});

const safeText = (value: unknown, maxLength = 4000) =>
  (typeof value === 'string' ? value : '').trim().slice(0, maxLength);

// Lazy-initialize Gemini SDK
let geminiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  if (!geminiClient) {
    geminiClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return geminiClient;
}

// Health check
app.get('/api/health', (_req: Request, res: Response) => {
  const hasKey = Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY');
  res.json({ status: 'ok', hasGeminiKey: hasKey, model: hasKey ? GEMINI_MODEL : null });
});

// AirKorea (data.go.kr) Open API Proxy & Educational Simulator
app.post('/api/airkorea-proxy', async (req: Request, res: Response) => {
  const startTime = Date.now();
  const stationName = safeText(req.body?.stationName, 50) || '송도';
  const dataTerm = safeText(req.body?.dataTerm, 20) || 'DAILY';
  const isMock = Boolean(req.body?.isMock);
  const rawKey = typeof req.body?.serviceKey === 'string' ? req.body.serviceKey.trim() : '';

  // Generate realistic Incheon station mock response matching exact AirKorea schema
  const generateMockResponse = (station: string) => {
    const now = new Date();
    const items = [];
    const basePm25 = station === '송도' ? 18 : station === '신흥동' ? 27 : station === '부평' ? 24 : station === '강화' ? 14 : 21;
    const basePm10 = Math.round(basePm25 * 1.8);

    for (let i = 0; i < 10; i++) {
      const itemTime = new Date(now.getTime() - i * 60 * 60 * 1000);
      const year = itemTime.getFullYear();
      const month = String(itemTime.getMonth() + 1).padStart(2, '0');
      const day = String(itemTime.getDate()).padStart(2, '0');
      const hour = String(itemTime.getHours()).padStart(2, '0');
      const timeStr = `${year}-${month}-${day} ${hour}:00`;
      
      const variance = (i % 3 === 0 ? 3 : i % 2 === 0 ? -2 : 1);
      const pm25 = Math.max(8, basePm25 + variance);
      const pm10 = Math.max(15, basePm10 + variance * 2);
      const khaiVal = Math.min(150, Math.round(pm25 * 2.8 + 15));
      const grade = khaiVal <= 50 ? '1' : khaiVal <= 100 ? '2' : khaiVal <= 250 ? '3' : '4';

      items.push({
        dataTime: timeStr,
        stationName: station,
        so2Value: '0.003',
        coValue: '0.5',
        o3Value: '0.027',
        no2Value: '0.019',
        pm10Value: String(pm10),
        pm10Value24: String(pm10 - 2),
        pm25Value: String(pm25),
        pm25Value24: String(pm25 - 1),
        khaiValue: String(khaiVal),
        khaiGrade: grade,
        so2Grade: '1',
        coGrade: '1',
        o3Grade: '1',
        no2Grade: '1',
        pm10Grade: pm10 <= 30 ? '1' : pm10 <= 80 ? '2' : '3',
        pm25Grade: pm25 <= 15 ? '1' : pm25 <= 35 ? '2' : '3',
      });
    }

    return {
      response: {
        header: {
          resultCode: '00',
          resultMsg: 'NORMAL_SERVICE',
        },
        body: {
          items,
          totalCount: 10,
          numOfRows: 10,
          pageNo: 1,
        },
      },
    };
  };

  // If mock mode or no service key provided, return structured educational simulator data
  if (isMock || !rawKey) {
    const mockData = generateMockResponse(stationName);
    const durationMs = Date.now() - startTime;
    return res.json({
      success: true,
      isMock: true,
      statusCode: 200,
      durationMs,
      stationName,
      message: '공공데이터포털 에어코리아 실시간 표준 규격 모의 시뮬레이터 응답입니다.',
      requestUrl: `https://apis.data.go.kr/B552584/ArpltnInforInqireSvc/getMsrstnAcctoRltmMesureDnsty?stationName=${encodeURIComponent(stationName)}&dataTerm=${dataTerm}&ver=1.0`,
      data: mockData,
    });
  }

  // Real data.go.kr API call with automatic decoding normalization to avoid double-encoding errors
  try {
    let cleanKey = rawKey;
    try {
      cleanKey = decodeURIComponent(rawKey);
    } catch {
      cleanKey = rawKey;
    }

    const apiUrl = new URL('https://apis.data.go.kr/B552584/ArpltnInforInqireSvc/getMsrstnAcctoRltmMesureDnsty');
    apiUrl.searchParams.set('serviceKey', cleanKey);
    apiUrl.searchParams.set('returnType', 'json');
    apiUrl.searchParams.set('numOfRows', '10');
    apiUrl.searchParams.set('pageNo', '1');
    apiUrl.searchParams.set('stationName', stationName);
    apiUrl.searchParams.set('dataTerm', dataTerm);
    apiUrl.searchParams.set('ver', '1.0');

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 9000);

    const apiResponse = await fetch(apiUrl.toString(), {
      method: 'GET',
      headers: {
        'Accept': 'application/json, text/xml, */*',
        'User-Agent': 'Incheon-4P-Edu-Applet',
      },
      signal: controller.signal,
    });

    clearTimeout(timeout);
    const durationMs = Date.now() - startTime;
    const responseText = await apiResponse.text();

    // Check if response is valid JSON
    let parsedData: any = null;
    let isJson = false;
    try {
      parsedData = JSON.parse(responseText);
      isJson = true;
    } catch {
      isJson = false;
    }

    if (isJson) {
      // Check if government returned an OpenAPI error header
      const openApiError = parsedData?.OpenAPI_ServiceResponse?.cmmMsgHeader;
      if (openApiError) {
        return res.json({
          success: false,
          isMock: false,
          statusCode: apiResponse.status,
          durationMs,
          stationName,
          error: `공공데이터포털 인증 오류: ${openApiError.returnAuthMsg || openApiError.errMsg || '인증키 미등록'} (사유코드: ${openApiError.returnReasonCode || '30'})`,
          hint: '인증키가 공공데이터포털 서버에 동기화 중이거나(신청 후 약 1시간 소요) 잘못 입력되었을 수 있습니다. 키가 승인되기 전에는 [모의 응답 시뮬레이터]로 먼저 실습을 진행하세요!',
          data: parsedData,
        });
      }

      // Check if government returned an internal error message inside response header
      const resultCode = parsedData?.response?.header?.resultCode;
      const resultMsg = parsedData?.response?.header?.resultMsg;

      if (resultCode && resultCode !== '00') {
        return res.json({
          success: false,
          isMock: false,
          statusCode: 200,
          durationMs,
          stationName,
          error: `공공데이터포털 오류 [${resultCode}]: ${resultMsg}`,
          hint: '인증키가 공공데이터포털 서버에 동기화 중이거나(신청 후 1~2시간 소요) 잘못 입력되었을 수 있습니다. [모의 응답 시뮬레이터]로 먼저 수업을 진행할 수 있습니다.',
          data: parsedData,
        });
      }

      return res.json({
        success: true,
        isMock: false,
        statusCode: apiResponse.status,
        durationMs,
        stationName,
        message: '정부 공공데이터포털(data.go.kr) 에어코리아 정식 라이브 응답 수신 성공',
        data: parsedData,
      });
    } else {
      // Response was XML (common for ServiceKey errors)
      let extractedError = '공공데이터포털 인증키 오류 (XML 응답 반환됨)';
      if (responseText.includes('SERVICE_KEY_IS_NOT_REGISTERED')) {
        extractedError = '등록되지 않은 인증키이거나 승인 후 서버 동기화 대기 중(1~2시간 소요)입니다.';
      } else if (responseText.includes('LIMITED_NUMBER_OF_SERVICE_REQUESTS')) {
        extractedError = '해당 인증키의 하루 호출 한도(1,000회)를 초과하였습니다.';
      } else if (responseText.includes('DEADLINE_HAS_EXPIRED')) {
        extractedError = '해당 인증키의 유효기간이 만료되었습니다.';
      }

      return res.json({
        success: false,
        isMock: false,
        statusCode: apiResponse.status,
        durationMs,
        stationName,
        error: extractedError,
        rawXmlSnippet: responseText.slice(0, 500),
        hint: '공공데이터포털에서 [한국환경공단 에어코리아 대기오염정보] 활용신청 승인 후 약 1시간이 지나야 공공데이터 게이트웨이에 등록됩니다. 키가 승인되기 전에는 [모의 응답 시뮬레이터]를 켜서 실습하세요!',
      });
    }
  } catch (err: any) {
    const durationMs = Date.now() - startTime;
    console.error('AirKorea proxy fetch error:', err);
    return res.json({
      success: false,
      isMock: false,
      statusCode: 504,
      durationMs,
      stationName,
      error: `정부 API 게이트웨이 통신 시간 초과 또는 네트워크 오류: ${err.message}`,
      hint: '정부 공공데이터포털 서버 점검 중이거나 응답이 지연되고 있습니다. 상단의 [모의 응답 시뮬레이터]를 선택하여 수업을 계속 진행하세요.',
    });
  }
});

// Universal Incheon Public Datasets (20 Recommended Datasets) Proxy & Educational Simulator
app.post('/api/gov-dataset-proxy', async (req: Request, res: Response) => {
  const startTime = Date.now();
  const datasetId = safeText(req.body?.datasetId, 80) || 'kosis-population-age';
  const district = safeText(req.body?.district, 80) || '연수구';
  const detail = safeText(req.body?.detail, 100);
  const isMock = Boolean(req.body?.isMock);
  const rawKey = typeof req.body?.serviceKey === 'string' ? req.body.serviceKey.trim() : '';

  const datasetDef = INCHEON_20_GOV_DATASETS.find((d) => d.id === datasetId) || INCHEON_20_GOV_DATASETS[0];

  // If mock mode or no serviceKey, return the official-structured simulator response
  if (isMock || !rawKey) {
    const mockData = datasetDef.generateMockData({ district, detail });
    const durationMs = Date.now() - startTime;
    return res.json({
      success: true,
      isMock: true,
      statusCode: 200,
      durationMs,
      datasetId: datasetDef.id,
      title: datasetDef.title,
      agency: datasetDef.agency,
      district,
      message: `대한민국 정부 공공데이터(${datasetDef.agency}) 표준 규격 모의 시뮬레이터 응답입니다.`,
      requestUrl: `${datasetDef.apiEndpoint}?district=${encodeURIComponent(district)}&returnType=json`,
      citation: datasetDef.sample4PCitation({ district, detail }),
      data: mockData,
    });
  }

  // Attempt real API call with normalized serviceKey
  try {
    let cleanKey = rawKey;
    try {
      cleanKey = decodeURIComponent(rawKey);
    } catch {
      cleanKey = rawKey;
    }

    const apiUrl = new URL(datasetDef.apiEndpoint);
    apiUrl.searchParams.set('serviceKey', cleanKey);
    apiUrl.searchParams.set('returnType', 'json');
    apiUrl.searchParams.set('numOfRows', '10');
    apiUrl.searchParams.set('pageNo', '1');
    if (district) {
      apiUrl.searchParams.set('district', district);
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 9000);

    const apiResponse = await fetch(apiUrl.toString(), {
      method: 'GET',
      headers: {
        'Accept': 'application/json, text/xml, */*',
        'User-Agent': 'Incheon-4P-Edu-Applet',
      },
      signal: controller.signal,
    });

    clearTimeout(timeout);
    const durationMs = Date.now() - startTime;
    const responseText = await apiResponse.text();

    let parsedData: any = null;
    let isJson = false;
    try {
      parsedData = JSON.parse(responseText);
      isJson = true;
    } catch {
      isJson = false;
    }

    if (isJson) {
      const openApiError = parsedData?.OpenAPI_ServiceResponse?.cmmMsgHeader;
      if (openApiError) {
        return res.json({
          success: false,
          isMock: false,
          statusCode: apiResponse.status,
          durationMs,
          datasetId: datasetDef.id,
          title: datasetDef.title,
          agency: datasetDef.agency,
          district,
          error: `공공데이터포털 인증 오류: ${openApiError.returnAuthMsg || openApiError.errMsg || '인증키 미등록'}`,
          hint: '해당 API에 대한 활용신청이 승인되었는지 확인하세요. 승인 전에는 [모의 응답 시뮬레이터]로 먼저 실습을 진행하세요!',
          data: parsedData,
          citation: datasetDef.sample4PCitation({ district, detail }),
        });
      }

      return res.json({
        success: true,
        isMock: false,
        statusCode: apiResponse.status,
        durationMs,
        datasetId: datasetDef.id,
        title: datasetDef.title,
        agency: datasetDef.agency,
        district,
        message: `정부 공공데이터(${datasetDef.agency}) 라이브 응답 수신 성공`,
        requestUrl: apiUrl.toString().replace(cleanKey, '***KEY_MASKED***'),
        citation: datasetDef.sample4PCitation({ district, detail }),
        data: parsedData,
      });
    } else {
      return res.json({
        success: false,
        isMock: false,
        statusCode: apiResponse.status,
        durationMs,
        datasetId: datasetDef.id,
        title: datasetDef.title,
        agency: datasetDef.agency,
        district,
        error: '공공데이터포털 XML 응답 수신 (인증키 미승인 또는 파라미터 오류)',
        rawXmlSnippet: responseText.slice(0, 500),
        hint: '공공데이터포털에서 해당 데이터셋 활용신청 후 1~2시간 승인 대기가 필요합니다. [모의 응답 시뮬레이터]를 활용해 수업을 계속 진행하세요.',
        citation: datasetDef.sample4PCitation({ district, detail }),
      });
    }
  } catch (err: any) {
    const durationMs = Date.now() - startTime;
    return res.json({
      success: false,
      isMock: false,
      statusCode: 504,
      durationMs,
      datasetId: datasetDef.id,
      title: datasetDef.title,
      agency: datasetDef.agency,
      district,
      error: `정부 게이트웨이 통신 시간 초과: ${err.message}`,
      hint: '네트워크 상태를 확인하시거나 상단의 [모의 응답 시뮬레이터]를 켜서 실습하세요.',
      citation: datasetDef.sample4PCitation({ district, detail }),
    });
  }
});

// AI 4P Question Evaluation Endpoint
app.post('/api/gemini/evaluate', async (req: Request, res: Response) => {
  try {
    const labName = safeText(req.body?.labName, 100);
    const question = safeText(req.body?.question, 1000);
    const phenomenon = safeText(req.body?.phenomenon);
    const problem = safeText(req.body?.problem);
    const project = safeText(req.body?.project);
    const practice = safeText(req.body?.practice);
    const ai = getGeminiClient();

    if (!ai) {
      // Fallback heuristic evaluation when no API key configured
      const fallbackResult = generateHeuristicEvaluation(labName, question, phenomenon, problem, project, practice);
      return res.json({ success: true, isFallback: true, data: fallbackResult });
    }

    const prompt = `
당신은 대한민국 교육청 '읽·걷·쓰(읽기-걷기-쓰기)' 기반 전공연계 사회문제탐구 전문 장학사이자 학술 멘토입니다.
학생이 제안한 4P(현상-문제-과업-실천) 탐구 질문 및 계획을 학술적·교육적 관점에서 정밀 평가하고 업그레이드 방안을 제시해주세요.

[탐구 정보]
- 전공 연구실: ${labName || '일반 연구'}
- 핵심 탐구 질문: ${question || '질문 미입력'}
- P1 현상(Phenomenon): ${phenomenon || '미작성'}
- P2 문제(Problem): ${problem || '미작성'}
- P3 과업(Project/Task - 전공 연구방법): ${project || '미작성'}
- P4 실천(Practice - 지역사회/사회적 적용): ${practice || '미작성'}

다음 JSON 형식으로만 정확히 반환해주세요. 추가 설명 문구 없이 오직 JSON만 출력해야 합니다:
{
  "totalScore": 88,
  "pScores": {
    "phenomenon": 22,
    "problem": 21,
    "project": 23,
    "practice": 22
  },
  "overallReview": "전반적인 탐구 평가 총평 (3~4문장)",
  "strengths": ["강점 1", "강점 2"],
  "improvements": ["개선할 점 1", "개선할 점 2"],
  "questionUpgrades": [
    {
      "level": "기본형 (현재)",
      "question": "${question || '원래 질문'}",
      "description": "현상 중심의 초기 질문"
    },
    {
      "level": "심화형 (전공 연계)",
      "question": "전공 개념 및 학술 분석이 포함된 심화 질문",
      "description": "문제 원인과 전공 학문적 관점이 연결된 질문"
    },
    {
      "level": "융합·실천형 (읽걷쓰 완성형)",
      "question": "현장 탐구(걷기)와 실제적 실천(쓰기)까지 관통하는 완성형 탐구 질문",
      "description": "지역사회 실천과 지속가능한 변화를 이끄는 질문"
    }
  ],
  "recommendedKeywords": ["키워드1", "키워드2", "키워드3", "키워드4"],
  "recommendedBooks": [
    {"title": "추천 도서/논문명", "author": "저자/기관", "reason": "이 책을 추천하는 이유"},
    {"title": "추천 도서/논문명2", "author": "저자/기관", "reason": "이 책을 추천하는 이유"}
  ],
  "practiceActionIdeas": [
    "구체적 실천 아이디어 1",
    "구체적 실천 아이디어 2"
  ]
}
`;

    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        temperature: 0.7,
      },
    });

    const text = response.text;
    if (!text) {
      throw new Error('Gemini API returned empty response');
    }

    const parsed = JSON.parse(text);
    return res.json({ success: true, isFallback: false, data: parsed });
  } catch (error: any) {
    console.error('Gemini evaluation error:', error);
    // Graceful fallback if Gemini API call fails
    const labName = safeText(req.body?.labName, 100);
    const question = safeText(req.body?.question, 1000);
    const phenomenon = safeText(req.body?.phenomenon);
    const problem = safeText(req.body?.problem);
    const project = safeText(req.body?.project);
    const practice = safeText(req.body?.practice);
    const fallbackResult = generateHeuristicEvaluation(labName, question, phenomenon, problem, project, practice);
    return res.json({ success: true, isFallback: true, error: error.message, data: fallbackResult });
  }
});

// AI Topic & Question Recommendation Endpoint
app.post('/api/gemini/recommend', async (req: Request, res: Response) => {
  try {
    const labName = safeText(req.body?.labName, 100);
    const interestKeyword = safeText(req.body?.interestKeyword, 200);
    const ai = getGeminiClient();

    if (!ai) {
      return res.json({
        success: true,
        isFallback: true,
        data: getFallbackRecommendations(labName, interestKeyword),
      });
    }

    const prompt = `
당신은 대한민국 '읽·걷·쓰' 전공연계 사회문제탐구 전문 연구위원입니다.
전공 연구실: "${labName}", 학생 관심 키워드: "${interestKeyword || '지역사회 지속가능성'}"을 바탕으로
학생이 탐구하기 좋은 매력적이고 시의성 있는 4P 사회문제탐구 주제 3가지를 추천해주세요.

다음 JSON 규격으로만 응답해주세요:
{
  "recommendations": [
    {
      "title": "주제명",
      "mainQuestion": "핵심 탐구 질문",
      "phenomenonSummary": "현상 요약",
      "problemSummary": "문제 요약",
      "projectSummary": "전공 탐구 과업",
      "practiceSummary": "실천 방안",
      "keywords": ["키워드1", "키워드2"],
      "recommendedBook": "관련 추천 도서명 (저자)"
    }
  ]
}
`;

    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        temperature: 0.8,
      },
    });

    const text = response.text;
    const parsed = JSON.parse(text || '{}');
    return res.json({ success: true, isFallback: false, data: parsed.recommendations || [] });
  } catch (error: any) {
    console.error('Gemini recommend error:', error);
    const labName = safeText(req.body?.labName, 100);
    const interestKeyword = safeText(req.body?.interestKeyword, 200);
    return res.json({
      success: true,
      isFallback: true,
      data: getFallbackRecommendations(labName, interestKeyword),
    });
  }
});

// Helper for realistic fallback evaluation
function generateHeuristicEvaluation(labName: string, question: string, phenomenon: string, problem: string, project: string, practice: string) {
  const p1Len = (phenomenon || '').length;
  const p2Len = (problem || '').length;
  const p3Len = (project || '').length;
  const p4Len = (practice || '').length;
  const qLen = (question || '').length;

  const p1Score = Math.min(25, Math.max(16, Math.floor(18 + (p1Len > 40 ? 5 : p1Len / 10))));
  const p2Score = Math.min(25, Math.max(15, Math.floor(17 + (p2Len > 40 ? 6 : p2Len / 10))));
  const p3Score = Math.min(25, Math.max(16, Math.floor(18 + (p3Len > 40 ? 6 : p3Len / 10))));
  const p4Score = Math.min(25, Math.max(15, Math.floor(17 + (p4Len > 40 ? 5 : p4Len / 10))));
  const totalScore = p1Score + p2Score + p3Score + p4Score;

  const baseQuestion = question && question.trim().length > 0 ? question.trim() : `${labName || '전공'} 기반 사회문제 해결을 위한 탐구`;

  return {
    totalScore,
    pScores: {
      phenomenon: p1Score,
      problem: p2Score,
      project: p3Score,
      practice: p4Score,
    },
    overallReview: `본 탐구는 [${labName || '선택 전공'}]의 학술적 시선으로 현실 문제를 포착하려는 의도가 돋보입니다. 현상과 문제의 인과관계를 더욱 실증적으로 연결하고, 걷기(현장 답사 및 관찰)를 통해 획득한 1차 데이터가 전공 연구 과업에 반영되면 더욱 탁월한 탐구 보고서로 발전할 수 있습니다.`,
    strengths: [
      '우리 주변 일상 및 지역사회에서 직관적으로 체감할 수 있는 현상을 연구 출발점으로 삼음',
      '전공 지식과 현실 문제의 접점을 모색하여 실천으로 확장하려는 4P 기본 프레임워크 준수',
    ],
    improvements: [
      '문제(Problem) 단계에서 단순 현상 나열을 넘어 사회적·구조적 근본 원인(메커니즘)을 더 명확히 기술할 것',
      '과업(Project) 단계에서 전공 특유의 연구 방법론(통계 분석, 문헌 고찰, 실험, 프로토타입 제작 등)을 구체화할 것',
    ],
    questionUpgrades: [
      {
        level: '기본형 (초기 제안)',
        question: baseQuestion,
        description: '관찰 가능한 현상에 주목한 초기 탐구 질문',
      },
      {
        level: '심화형 (전공 개념 접목)',
        question: `${baseQuestion.replace(/[?？]$/, '')}에 대한 ${labName || '전공'} 관점의 인과 구조 분석과 실증적 대안은 무엇인가?`,
        description: '학술적 분석 틀과 상관관계를 규명하는 심층 질문',
      },
      {
        level: '융합·실천형 (읽걷쓰 종합형)',
        question: `현장 사색(걷기)과 데이터 분석을 통해 규명한 ${baseQuestion.replace(/[?？]$/, '')}의 지속가능한 해결책과 지역사회 실천 모델은 어떻게 구현되는가?`,
        description: '인문학적 사색과 실증 연구, 구체적 실천이 통합된 완성형 질문',
      },
    ],
    recommendedKeywords: [
      `${labName || '전공'} 방법론`,
      '지역사회 거버넌스',
      '데이터 기반 실천',
      '사회적 가치 측정',
      '현장 참여형 연구',
    ],
    recommendedBooks: [
      {
        title: '문제 해결의 사회학',
        author: '한국사회학회',
        reason: '사회문제를 개인의 문제가 아닌 구조적 맥락에서 다각도로 조망하는 시각을 제공합니다.',
      },
      {
        title: '탐구하는 인간: 호모 인콰이런스',
        author: '교육과실천연구회',
        reason: '읽기와 걷기를 통해 축적한 생각을 논리적인 쓰기로 완성하는 탐구 방법론을 안내합니다.',
      },
    ],
    practiceActionIdeas: [
      '학교 또는 지역 공공게시판/SNS를 활용한 문제인식 개선 인포그래픽 캠페인 진행',
      '관련 지방자치단체 열린 정책제안 창구(인천시 소통참여 등)에 4P 분석 보고서 요약본 제출',
      '교내 학생회 및 동아리 연계 실천 프로젝트 시범 운영 및 전후 효과 설문조사',
    ],
  };
}

function getFallbackRecommendations(labName: string, keyword?: string) {
  const kw = keyword || '지역사회 발전';
  return [
    {
      title: `${labName || '융합'} 관점에서 본 ${kw} 격차 해소 모델`,
      mainQuestion: `우리 지역에서 체감되는 ${kw}의 불평등 현상을 어떻게 ${labName || '전공'} 기법으로 완화할 수 있을까?`,
      phenomenonSummary: '지역 내 인프라 및 접근성 편차로 인한 계층별·세대별 체감 격차 발생',
      problemSummary: '단순 자원 부족이 아닌 공급자 중심 정책과 주민 피드백 루프의 부재',
      projectSummary: '현장 실태 설문조사 및 해외 모범사례 비교분석을 통한 전공 솔루션 도출',
      practiceSummary: '청소년 주도 정책제안서 작성 및 교내 공론화 원탁회의 개최',
      keywords: [kw, '지역격차', '사회적자본', '실천모델'],
      recommendedBook: '로컬의 진화 (김영준 저)',
    },
    {
      title: `디지털 전환 시대의 ${kw}과 인간 중심 지속가능성`,
      mainQuestion: `${kw} 분야의 급격한 디지털 기술 도입 과정에서 소외되는 주체들을 어떻게 보호할 것인가?`,
      phenomenonSummary: '무인화, 자동화 가속화에 따른 노인·취약계층의 이용 단절 및 심리적 고립',
      problemSummary: '효율성 중심 기술 도입과 포용적 UI/UX 및 사회안전망 설계 미흡',
      projectSummary: '사용자 여정 맵핑(User Journey Mapping) 및 기술 수용도 모델 분석',
      practiceSummary: '디지털 튜터링 봉사활동 기획 및 친화적 가이드라인 매뉴얼 발간',
      keywords: ['디지털포용', '접근성', '인간중심기술', '사용자경험'],
      recommendedBook: '다정한 기술 (이민석 저)',
    },
    {
      title: `생태적 전환을 위한 ${kw} 기반 순환경제 실천`,
      mainQuestion: `일상 폐기물 감축과 탄소발자국 저감을 위해 ${labName || '전공'}에서 제안할 수 있는 시스템 혁신은?`,
      phenomenonSummary: '일회용품 소비 급증 및 재활용 선별 처리 과정의 비용 증가와 비효율',
      problemSummary: '생산-소비-폐기 선형 구조의 한계와 실천 동기 유발 인센티브 결여',
      projectSummary: '물질 흐름 분석(MFA) 및 행동경제학적 넛지(Nudge) 디자인 적용 연구',
      practiceSummary: '교내 보증금제 텀블러 순환 스테이션 구축 및 탄소포인트 챌린지 운영',
      keywords: ['순환경제', '탄소중립', '넛지디자인', '행동변화'],
      recommendedBook: '우리는 지구를 포기하지 않는다 (최재천 저)',
    },
  ];
}

// Vite middleware configuration
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`4P 읽걷쓰 전공연계 사회문제탐구 server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
