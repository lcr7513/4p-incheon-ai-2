export type LabId =
  | 'humanities'
  | 'business'
  | 'tech'
  | 'science'
  | 'bio'
  | 'education';

export type WalkingDomainId =
  | 'contemplation'       // 사색·성찰형 걷기
  | 'field-observation'  // 현장답사·공간관찰형 걷기
  | 'interview-dialogue'  // 사람·소통·인터뷰형 걷기
  | 'literature-history'  // 역사·문학기행형 걷기
  | 'eco-nature'          // 생태·자연탐사형 걷기
  | 'action-campaign'     // 실천·연대·캠페인형 걷기
  | 'platform-walk'       // 플랫폼 걷기 (배달·모빌리티·알고리즘)
  | 'data-walk';          // 데이터 걷기 (스마트센싱·환경측정·GIS)

export interface WalkingDomainInfo {
  id: WalkingDomainId;
  name: string;
  englishName: string;
  subtitle: string;
  badge: string;
  themeColor: string;
  badgeColor: string;
  bgLight: string;
  borderColor: string;
  iconName: string;
  summary: string;
  philosophy: string;
  methods: string[];
  inquiryKeywords: string[];
  inquiryQuestions: string[];
  sampleActivities: {
    title: string;
    purpose: string;
    target4P: 'P1' | 'P2' | 'P3' | 'P4';
    stepsToTake: string[];
    expectedOutcome: string;
    injectContent: string;
  }[];
  checklists: string[];
  recommendedSpots: {
    name: string;
    location: string;
    features: string;
    contemplationPrompt: string;
  }[];
}

export interface WalkingSpot {
  id: string;
  name: string;
  subName?: string;
  location: string;
  district: string;
  imageUrl: string;
  imageCaption: string;
  incheonFeatures: string; // 인천 고유의 장소적·역사적·지리적 특징 설명
  historicalBackground?: string; // 역사·공간적 배경
  reason: string;
  inquiryConnection: string; // 전공 연구실과의 연계 착안점
  contemplationPrompt: string;
  courseDistance?: string; // 소요거리 및 시간
  keySpots: string[]; // 주요 경유지
  tags: string[];
  photoCredit?: string; // 사진 출처 및 라이선스 (Unsplash License, 공공누리 등)
  isRealIncheonPhoto?: boolean; // 실제 인천 현장 촬영 사진 여부
}

export interface LabInfo {
  id: LabId;
  name: string;
  englishName: string;
  badge: string;
  themeColor: string;
  badgeColor: string;
  bgLight: string;
  borderColor: string;
  iconName: string;
  summary: string;
  description: string;
  coreMajors: string[];
  inquiryKeywords: string[];
  inquiryCoreQuestions: string[];
  sampleTopics: {
    title: string;
    mainQuestion: string;
    p1: string;
    p2: string;
    p3: string;
    p4: string;
    keywords: string[];
  }[];
  recommendedReadings: {
    title: string;
    author: string;
    badge: string;
    description: string;
  }[];
  walkingSpots: WalkingSpot[];
}

export interface WalkingLog {
  id: string;
  date: string;
  steps: number;
  durationMinutes: number;
  courseName: string;
  thoughtNote: string;
  focusScore: number; // 1 ~ 5
  linked4PStep: 'P1' | 'P2' | 'P3' | 'P4' | 'general';
  domainId?: WalkingDomainId;
  activityType?: string;
  findings?: string;
}

export interface ReadingLog {
  id: string;
  title: string;
  author: string;
  category: string;
  readingNotes: string;
  date: string;
}

export interface FourPData {
  phenomenon: string; // P1 현상
  problem: string;    // P2 문제
  project: string;    // P3 과업
  practice: string;   // P4 실천
}

export interface QuestionUpgrade {
  level: string;
  question: string;
  description: string;
}

export interface EvaluationResult {
  totalScore: number;
  pScores: {
    phenomenon: number;
    problem: number;
    project: number;
    practice: number;
  };
  overallReview: string;
  strengths: string[];
  improvements: string[];
  questionUpgrades: QuestionUpgrade[];
  recommendedKeywords: string[];
  recommendedBooks: {
    title: string;
    author: string;
    reason: string;
  }[];
  practiceActionIdeas: string[];
  isFallback?: boolean;
}

export interface ResearchProject {
  id: string;
  title: string;
  labId: LabId;
  author: string;
  affiliation: string;
  mainQuestion: string;
  fourP: FourPData;
  walkingLogs: WalkingLog[];
  readingLogs: ReadingLog[];
  evaluationResult?: EvaluationResult | null;
  createdAt: string;
  updatedAt: string;
  /** 모범 예시/아카이브 자료인지 사용자가 작성하는 실제 프로젝트인지 구분 */
  isDemo?: boolean;
}

export type ActiveTab =
  | 'dashboard'
  | 'labs'
  | 'workspace'
  | 'ai-evaluator'
  | 'walking-mind'
  | 'archive'
  | 'experimental-lab';
