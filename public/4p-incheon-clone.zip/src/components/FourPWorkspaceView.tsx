import React, { useState } from 'react';
import {
  PenTool,
  Sparkles,
  Printer,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  RotateCcw,
  Save,
  BookOpen,
  Footprints,
  FileCheck,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { ResearchProject, FourPData, LabId } from '../types';
import { LABS_DATA } from '../data/labsData';

interface FourPWorkspaceViewProps {
  project: ResearchProject;
  onChangeProject: (updated: Partial<ResearchProject>) => void;
  onRequestAiEvaluation: () => void;
  onOpenPreview: () => void;
  onResetToDemo: () => void;
}

export const FourPWorkspaceView: React.FC<FourPWorkspaceViewProps> = ({
  project,
  onChangeProject,
  onRequestAiEvaluation,
  onOpenPreview,
  onResetToDemo,
}) => {
  const [activeStep, setActiveStep] = useState<'P1' | 'P2' | 'P3' | 'P4'>('P1');
  const [savedToast, setSavedToast] = useState(false);

  const currentLab = LABS_DATA.find((l) => l.id === project.labId) || LABS_DATA[0];

  const handleFourPChange = (field: keyof FourPData, value: string) => {
    onChangeProject({
      fourP: {
        ...project.fourP,
        [field]: value,
      },
      updatedAt: new Date().toISOString().split('T')[0],
    });
  };

  const handleSave = () => {
    setSavedToast(true);
    setTimeout(() => setSavedToast(false), 2000);
  };

  const stepsConfig = [
    {
      id: 'P1' as const,
      field: 'phenomenon' as const,
      title: 'P1. 현상 (Phenomenon)',
      subtitle: '일상과 사회에서 포착한 사실적 데이터 및 관찰 현상',
      guide: [
        '“어떤 현상이 일어나고 있는가?” 구체적인 사실(Fact)을 기술하세요.',
        '신문 기사, 지역 통계, 학교 일상에서 직접 목격하거나 조사한 수치를 인용하면 좋습니다.',
        '걷기(현장 답사)를 통해 직접 관찰한 구체적 공간과 사람들의 모습을 기록하세요.',
      ],
      placeholder:
        '예: 우리 지역 원도심 상가에서 키오스크 전환이 급증하여, 노인 고객의 68%가 이용 포기를 경험하고 있는 현상을 목격하였습니다...',
      color: 'border-indigo-500 text-indigo-600',
      badge: 'bg-indigo-50 text-indigo-700 border-indigo-200',
    },
    {
      id: 'P2' as const,
      field: 'problem' as const,
      title: 'P2. 문제 (Problem)',
      subtitle: '현상 이면의 구조적 모순, 원인 분석 및 해결의 당위성',
      guide: [
        '“이것이 왜 방치할 수 없는 사회적 문제인가?” 근본 원인을 분석하세요.',
        '개인의 부주의나 우연이 아니라, 제도, 문화, 기술, 자본 등 구조적 메커니즘을 밝히세요.',
        '이 문제가 지속될 경우 발생할 사회적 비용이나 인권, 불평등 문제를 짚어보세요.',
      ],
      placeholder:
        '예: 이는 단순한 사용 불편이 아니라 고령층의 디지털 기본권 침해이며, 효율성 중심의 기술 도입이 낳은 사회적 배제 문제입니다...',
      color: 'border-blue-500 text-blue-600',
      badge: 'bg-blue-50 text-blue-700 border-blue-200',
    },
    {
      id: 'P3' as const,
      field: 'project' as const,
      title: 'P3. 과업 (Project / Task)',
      subtitle: '전공 학문적 이론과 연구방법론을 적용한 해결 탐구 과제',
      guide: [
        '“선택한 전공 학문에서는 이 문제를 어떻게 접근하고 규명할 수 있는가?”',
        '전공 관련 이론(예: 사회학의 배제 이론, 공학의 엣지 센싱, 환경학의 탄소 분석 등)을 명시하세요.',
        '구체적인 연구 방법(설문조사, 심층 인터뷰, 실험, A/B 테스트, 데이터 분석)을 계획하세요.',
      ],
      placeholder:
        '예: 인문사회학적 공론장 이론을 바탕으로 어르신 대상 FGI 심층 인터뷰를 실시하고, 상업 무인기기 UI/UX 체크리스트를 전공 관점에서 평가합니다...',
      color: 'border-purple-500 text-purple-600',
      badge: 'bg-purple-50 text-purple-700 border-purple-200',
    },
    {
      id: 'P4' as const,
      field: 'practice' as const,
      title: 'P4. 실천 (Practice)',
      subtitle: '학교, 지역사회, 제도, 기술 등 구체적인 실천과 지속가능한 변화',
      guide: [
        '“우리는 연구 결과를 바탕으로 무엇을 직접 실천할 것인가?”',
        '단순 제언에 그치지 않고, 학교 내 캠페인, 조례 청원, 앱 프로토타입 배포, 봉사활동 등 실행 가능한 액션을 적으세요.',
        '지역사회 유관기관(지자체, 상인회, 학교 등)과의 연계 방안을 포함하세요.',
      ],
      placeholder:
        '예: 1) 신포시장 매장에 부착할 친절 가이드 스티커 제작 배포, 2) 시의회에 고령자 디지털 기본권 보장 조례 제정안 청원서 제출...',
      color: 'border-emerald-500 text-emerald-600',
      badge: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Top Header & Project Metadata Input */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
                4P 탐구 워크스페이스
              </span>
              <span className="text-xs text-slate-500">연구 계획서 실시간 편집</span>
            </div>
            <h2 className="text-xl font-bold text-slate-900">4P 연구 계획서 작성 및 정교화</h2>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="btn-save-project"
              onClick={handleSave}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-medium transition-all"
            >
              <Save className="w-3.5 h-3.5" />
              <span>저장</span>
            </button>

            <button
              id="btn-request-eval"
              onClick={onRequestAiEvaluation}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold shadow-xs transition-all"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>AI 질문 평가받기</span>
            </button>

            <button
              id="btn-preview-modal"
              onClick={onOpenPreview}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-medium transition-all"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>미리보기</span>
            </button>
          </div>
        </div>

        {savedToast && (
          <div className="mt-3 p-2 bg-emerald-50 text-emerald-800 text-xs rounded-lg border border-emerald-200 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>연구 계획서 내용이 브라우저 로컬 저장소에 안전하게 저장되었습니다.</span>
          </div>
        )}

        {/* Form Fields: Lab, Title, Author, Affiliation */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-5">
          <div className="md:col-span-1">
            <label className="block text-xs font-semibold text-slate-700 mb-1">참여 연구실 (전공)</label>
            <select
              id="select-project-lab"
              value={project.labId}
              onChange={(e) => onChangeProject({ labId: e.target.value as LabId })}
              className="w-full text-xs rounded-lg border border-slate-300 p-2.5 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
            >
              {LABS_DATA.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.name} ({l.badge})
                </option>
              ))}
            </select>
          </div>

          <div className="md:col-span-2">
            <label className="block text-xs font-semibold text-slate-700 mb-1">연구 주제 (프로젝트 제목)</label>
            <input
              id="input-project-title"
              type="text"
              value={project.title}
              onChange={(e) => onChangeProject({ title: e.target.value })}
              placeholder="예: 초고령 사회 무인화 매장 확산에 따른 노인 디지털 기본권 침해와 포용적 공론장 설계"
              className="w-full text-xs rounded-lg border border-slate-300 p-2.5 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
            />
          </div>

          <div className="md:col-span-1">
            <label className="block text-xs font-semibold text-slate-700 mb-1">연구자 / 소속</label>
            <div className="grid grid-cols-2 gap-2">
              <input
                id="input-project-author"
                type="text"
                value={project.author}
                onChange={(e) => onChangeProject({ author: e.target.value })}
                placeholder="연구자 성명"
                className="text-xs rounded-lg border border-slate-300 p-2.5 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
              <input
                id="input-project-affiliation"
                type="text"
                value={project.affiliation}
                onChange={(e) => onChangeProject({ affiliation: e.target.value })}
                placeholder="소속 학교/학년"
                className="text-xs rounded-lg border border-slate-300 p-2.5 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>
          </div>
        </div>

        {/* Main Research Question Input */}
        <div className="mt-4">
          <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center justify-between">
            <span>핵심 탐구 질문 (Research Question)</span>
            <span className="text-[11px] text-indigo-600 font-normal">
              * 4P 전체를 관통하는 학술적·실천적 질문을 작성하세요
            </span>
          </label>
          <input
            id="input-project-question"
            type="text"
            value={project.mainQuestion}
            onChange={(e) => onChangeProject({ mainQuestion: e.target.value })}
            placeholder="예: 무인화 기술 도입 과정에서 노인의 일상적 접근권과 자기결정권은 어떻게 보장될 수 있는가?"
            className="w-full text-xs font-medium text-slate-900 rounded-lg border border-indigo-200 bg-indigo-50/20 p-2.5 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
          />
        </div>
      </div>

      {/* 4P Step-by-Step Interactive Cards */}
      <div className="space-y-4">
        {stepsConfig.map((step) => {
          const content = project.fourP[step.field] || '';
          const charCount = content.length;
          const isComplete = charCount >= 40;
          const isOpened = activeStep === step.id;

          return (
            <div
              key={step.id}
              className={`bg-white rounded-2xl border transition-all duration-150 overflow-hidden shadow-xs ${
                isOpened ? 'ring-2 ring-indigo-500/20 border-indigo-300' : 'border-slate-200/80'
              }`}
            >
              {/* Header Toggle */}
              <div
                id={`step-header-${step.id}`}
                onClick={() => setActiveStep(isOpened ? (step.id === 'P1' ? 'P2' : 'P1') : step.id)}
                className="p-5 flex items-center justify-between cursor-pointer hover:bg-slate-50/60 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <span className={`px-2.5 py-1 rounded-md text-xs font-bold border ${step.badge}`}>
                    {step.id}
                  </span>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                      {step.title}
                    </h3>
                    <p className="text-xs text-slate-500 hidden sm:block">{step.subtitle}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span className="text-xs text-slate-400 font-mono">
                    {charCount}자 {isComplete ? '(작성 완료)' : '(내용 보강 권장)'}
                  </span>
                  {isComplete ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-amber-500" />
                  )}
                  {isOpened ? (
                    <ChevronUp className="w-4 h-4 text-slate-400" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-slate-400" />
                  )}
                </div>
              </div>

              {/* Step Editor Body */}
              {isOpened && (
                <div className="p-5 pt-0 border-t border-slate-100 bg-slate-50/30">
                  {/* Step Pedagogical Guide Box */}
                  <div className="my-3 p-3.5 rounded-xl bg-slate-100/70 border border-slate-200 text-xs text-slate-700 space-y-1">
                    <span className="font-semibold text-slate-900 flex items-center gap-1">
                      <HelpCircle className="w-3.5 h-3.5 text-indigo-600" />
                      작성 나침반 (가이드 질문):
                    </span>
                    <ul className="list-disc list-inside space-y-0.5 text-slate-600 pl-1">
                      {step.guide.map((g, i) => (
                        <li key={i}>{g}</li>
                      ))}
                    </ul>
                  </div>

                  {/* Textarea */}
                  <div className="relative mt-2">
                    <textarea
                      id={`textarea-${step.field}`}
                      rows={5}
                      value={content}
                      onChange={(e) => handleFourPChange(step.field, e.target.value)}
                      placeholder={step.placeholder}
                      className="w-full text-xs text-slate-800 leading-relaxed rounded-xl border border-slate-300 p-3.5 bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden resize-y font-normal"
                    />
                  </div>

                  {/* Footer hint */}
                  <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
                    <span>최소 40자 이상 구체적으로 작성할 때 AI 질문 평가의 정밀도가 극대화됩니다.</span>
                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          const nextSteps: Record<string, 'P1' | 'P2' | 'P3' | 'P4'> = {
                            P1: 'P2',
                            P2: 'P3',
                            P3: 'P4',
                            P4: 'P1',
                          };
                          setActiveStep(nextSteps[step.id]);
                        }}
                        className="text-xs font-semibold text-indigo-600 hover:text-indigo-800"
                      >
                        다음 단계로 &rarr;
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Action Footer */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h4 className="text-sm font-bold flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-indigo-400" />
            4P 계획서가 완성되었나요?
          </h4>
          <p className="text-xs text-slate-400 mt-0.5">
            Gemini 연동 AI 또는 규칙 기반 안전 모드가 질문의 학술적 깊이와 4P 정합성을 점검하고 심화 질문을 제안합니다.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onResetToDemo}
            className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-medium transition-all flex items-center gap-1.5"
            title="모범 탐구 예시로 복원"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>예시 템플릿 복원</span>
          </button>

          <button
            id="btn-footer-eval"
            onClick={onRequestAiEvaluation}
            className="px-4 py-2 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-900/40 transition-all flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI 정밀 평가 실행</span>
          </button>
        </div>
      </div>
    </div>
  );
};
